/* Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, May 7, 2023
 * Code description: Implementing Dictionaries using Binary search trees
 * Files: Node.java, Word_Definition.java
 */
package Q1;
import java.io.BufferedReader;
import java.io.*;
import java.io.FileReader;
import java.util.*;

//Start of class
public class BST_Dictionary {
protected Node root;
	//Constructor
	public BST_Dictionary() {
		root = null;
	}
	//Accessors
	public Node getRoot() {
		return root;
	}
	
	public void setRoot(Node root) {
		this.root = root;
	}



	public static Node createDictionary(Node r, int tries) {
		/* Description: The function prompts the user for a file name in which it then checks for present words and their definitions seperated by a ":" to create a new dictionary.
		 * The user has 3 tries only to input the file name before returning to the menu. The words are inserted in lexicographical order. They are represented as Nodes.
		 * Parameters: 
		 * 1- Node r: The root of our dictionary.
		 * Return type: Node, returns the root of the BST.
		 */
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the name of your desired file: ");
		String file_name = scan.next();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file_name));
			String line = br.readLine();
			while (line != null) {
				String [] definition = line.split(":");
				if (definition.length == 2) {
					String word = definition[0];
					String description = definition [1];
					Word_Definition wd = new Word_Definition (word, description);
					r = insert(r, wd);
					line = br.readLine();
				}	
			}
			br.close();
			System.out.println("Dictionary created successfully.");
		}
		catch (Exception e) {
			if (tries < 2) {
	            tries++;
	            System.out.println("File was not found, try again! You have " + (3-tries) + " try/ies left.");
	            r = createDictionary(r,tries);
	        }
			
			else {
	            System.out.println("Max attempts reached. Returning to menu.");
	        }
	    }
	    return r;	
	}

	
	private static Node insert (Node root, Word_Definition wd) {
		/* Description: The function recursively inserts Nodes to the left or to the right based on lexicographical order.
		 * 1- Node root: The root of our dictionary.
		 * 2- Word_Definition wd: The Word_Definition to be added to the dictionary.
		 * Return type: Node, returns the root of the BST.
		 */
		if (root == null) {
			root = new Node (wd);
		}
		
		else if (wd.getWord().compareTo(root.wd.getWord()) <= 0) {
			root.setLeft(insert(root.getLeft(), wd));
			root.getLeft().setParent(root);
		}
		
		else if (wd.getWord().compareTo(root.wd.getWord()) > 0) {
			root.setRight(insert(root.getRight(), wd));
			root.getRight().setParent(root);
		}
		
		//checks if definition already exists
		else if (wd.getWord().compareTo(root.wd.getWord()) == 0 && wd.getDescription().compareTo(root.wd.getDescription()) == 0) {
			System.out.println("Definition already exists.");
		}
		
		
		return root;
	}
	
	public static Node add_Definition (Node root, Word_Definition wd) {
		/* Description: The function recursively inserts Nodes to the left or to the right based on lexicographical order.
		 * 1- Node root: The root of our dictionary.
		 * 2- Word_Definition wd: The Word_Definition to be added to the dictionary.
		 * Return type: Node, returns the root of the BST.
		 */
		if (root == null) {
			root = new Node (wd);
			return root;
		}

		else if (wd.getWord().compareTo(root.wd.getWord()) <= 0) {
			if (root.getRight() == null) {
				root.setLeft(new Node (wd));
				root.getLeft().setParent(root);
			}
			
			else {
			add_Definition(root.getLeft(),wd);
			}
		}
		
		else if (wd.getWord().compareTo(root.wd.getWord()) > 0) {
			if (root.getRight() == null) {
				root.setRight(new Node(wd));
				root.getRight().setParent(root);
			}
			else {
			add_Definition(root.getRight(),wd);
			}
		}
		
		else if (wd.getWord().compareTo(root.wd.getWord()) == 0 && wd.getDescription().compareTo(root.wd.getDescription()) == 0) {
			System.out.println("Definition already exists.");
		}
		
		return root;
	}
	
	public Node locate (Node root, String key, String desc) {
		/* Description: The function recursively locates a specific Node based on the key and description provided. 
		 * It makes use of the fact that this is a BST and the order is lexicographical.
		 * 1- Node root: The root of our dictionary.
		 * 2- String key: word we are interested in.
		 * 3- String desc: description we are interested in.
		 * Return type: Node, returns required node.
		 */
	    if (root == null) {
	        return null;
	    }

	    int compare = key.compareTo(root.wd.getWord());

	    if (compare == 0 && root.wd.description.equals(desc) ) {
	        return root;
	    }

	    if (compare < 0) {
	        return locate (root.getLeft(), key, desc);
	    } 
	    
	    else {
	        return locate (root.getRight(), key, desc);
	    }
	}
	
	
	public void find (Node root, String key, String desc, ArrayList<Node> a) {
		/* Description: The function recursively finds all nodes that have key and description provided and adds them to an ArrayList.
		 * It makes use of the fact that this is a BST and the order is lexicographical.
		 * 1- Node root: The root of our dictionary.
		 * 2- String key: word we are interested in.
		 * 3- String desc: description we are interested in.
		 * Return type: Node, returns required node.
		 */
		if (root == null) {
	        return;
	    }
	    if (root.wd.getWord().equals(locate(root,key,desc).wd.getWord())) 
	    		if (root.wd.getDescription().equals(locate(root,key,desc).wd.getDescription())) {
	    			a.add(root);
	    }
	    find (root.getLeft(), key, desc, a );
	    find (root.getRight(), key, desc, a);
	}
			
	
	public void delete (Node root, String key, String desc) {
		/* Description: The function deletes a Node from the Dictionary. It prompts the user to choose which word he wants to delete if multiple definitions exist.
		 * 1- Node root: The root of our dictionary.
		 * 2- String key: word we are interested in.
		 * 3- String desc: description we are interested in.
		 * Return type: void (Nothing).
		 */
		Scanner scan = new Scanner(System.in);
		Node delete_Node = locate (root, key, desc);
		if (delete_Node == null) {
			System.out.println("No nodes containing this word and description to delete found.");
			return;
		}
		
		ArrayList <Node> a = new ArrayList<>();
		find (root,key,desc,a);
		if (a.size()==1) {
			deleteNode(a.get(0));
	        System.out.println("Definition deleted successfully. ");
		}
		 
		else {
	        System.out.println("Multiple definitions found for the word: " + key);
	        System.out.println("Choose the number of the definition to delete: ");
	        for (int i = 0; i < a.size(); i++) {
	            System.out.println(i + 1 + ". " + a.get(i).getWd());
	        }
	        int choice = scan.nextInt();
	        if (choice < 1 || choice > a.size()) {
	            System.out.println("Invalid choice. ");
	            return;
	        }
	        deleteNode(a.get(choice - 1));
	        System.out.println("Definition deleted successfully. ");
	    }
	}
	
	
	private void deleteNode(Node nodeToDelete) {
		/* Description: The function deletes a Node from the BST. It corrects the attachments between the nodes after deletion.
		 * 1- Node nodeToDelete: Node to be deleted. 
		 * Return type: void (Nothing).
		 */
	    if (nodeToDelete.getLeft() == null && nodeToDelete.getRight() == null) {
	        if (nodeToDelete.getParent() == null) {
	            root = null;
	            return;
	        }
	        
	        if (nodeToDelete.getParent().getLeft() == nodeToDelete) {
	            nodeToDelete.getParent().setLeft(null);
	        } 
	        
	        else {
	            nodeToDelete.getParent().setRight(null);
	        }
	    } 
	    
	    else if (nodeToDelete.getLeft() != null && nodeToDelete.getRight() != null) {
	        Node successor = getSuccessor(nodeToDelete);
	        nodeToDelete.setWd(successor.getWd());
	        deleteNode(successor);
	    }
	    
	    else {
	        Node child = nodeToDelete.getLeft() != null ? nodeToDelete.getLeft() : nodeToDelete.getRight();
	        if (nodeToDelete.getParent() == null) {
	            root = child;
	            child.setParent(null);
	            return;
	        }
	        
	        if (nodeToDelete.getParent().getLeft() == nodeToDelete) {
	            nodeToDelete.getParent().setLeft(child);
	        } 
	        
	        else {
	            nodeToDelete.getParent().setRight(child);
	        }
	        child.setParent(nodeToDelete.getParent());
	    }
	}
	
	private Node getSuccessor(Node nodeToDelete) {
		/* Description: Gets successor of specified node.
		 * 1- Node nodeToDelete: Node to be deleted.
		 * Return Node: returns successor node.
		 */
	    Node successor = nodeToDelete.getRight();
	    while (successor.getLeft() != null) {
	        successor = successor.getLeft();
	    }
	    return successor;
	}
	
	public void search (Node root, String word,int count) {
		/* Description: The function recursively searches for all definitions of a word in the dictionary. 
		 * 1- Node root: The root of our dictionary.
		 * 2- String word: word we are interested in.
		 * 3- int count: How many times did we encounter this word.
		 * Return type: void (Nothing).
		 */
		    if (root == null) {
		        return;
		    }

		    int compare = word.compareTo(root.wd.getWord());

		    if (compare == 0) {
		        System.out.println(count + "." + " Definition: " + root.wd.getDescription());
		        System.out.println();
		        count++;
		    }

		    search (root.getLeft(), word, count);
		    search (root.getRight(), word, count);
		}
	
	public static void traverseAndPrint(Node root) {
		/* Description: The function recursively traverses a dictionary and prints all its word definitions.
		 * 1- Node root: The root of our dictionary.
		 * Return type: void (Nothing).
		 */
	    if (root != null) {
	        traverseAndPrint(root.getLeft()); 
	        System.out.println(root.getWd()); 
	        traverseAndPrint(root.getRight()); 
	    }
	}
	
	
	public static void menu() {
		/* Description: Menu.
		 * Return type: void (Nothing).
		 */
		Scanner scan = new Scanner(System.in);
		// ArrayList of dictionaries.
		ArrayList <BST_Dictionary> dictionaries = new ArrayList<>();
		int choice = 0;
		while (choice!=5) {
			//Menu
			System.out.println("1. Create Dictionary\r\n"
					+ "2. Add a definition\r\n"
					+ "3. Delete a definition\r\n"
					+ "4. Search for a definition\r\n"
					+ "5. Exit\r\n"
					+ "----------------------\r\n"
					+ "Enter your choice:");
			choice = scan.nextInt();
			switch(choice) {
			
			case 1:
				// Create dictionary then add it to the ArrayList.
				BST_Dictionary dictionary = new BST_Dictionary();
				dictionary.setRoot (createDictionary(dictionary.getRoot(),0));
				dictionaries.add(dictionary);
				break;
				
			case 2:
				//Prompts the user for the word and its definition then asks them if they want to add it to a new or existing dictionary.
				System.out.println("Enter desired word: ");
				String word = scan.next();
				System.out.println("Enter desired description: ");
				String description = scan.next();
				Word_Definition wd = new Word_Definition(word, description);
				System.out.println("Choose 0 if you want to add the word to an existing dictionary or 1 to create a new dictionary: ");
				int choose = scan.nextInt();
				if (choose == 0) {
					for (int i = 0; i<dictionaries.size();i++) {
						if(dictionaries.get(i) != null) {
							System.out.println((i+1) + "- Dictionary of root: " + dictionaries.get(i).getRoot().getWd().toString());
						}
					}
					System.out.println("Pick desired dictionary: ");
					int set = scan.nextInt();
					if (set < 1 || set > dictionaries.size()) {
				            System.out.println("Invalid choice");
				            return;
				        }
				        BST_Dictionary dict = dictionaries.get(set - 1);
				        dict.setRoot(add_Definition (dict.getRoot(),wd));
				        System.out.println("Definition added successfully! ");
				        traverseAndPrint(dict.getRoot());
				}
				
				else if (choose == 1) {
					BST_Dictionary new_dictionary = new BST_Dictionary();
					dictionaries.add(new_dictionary);
					new_dictionary.setRoot(add_Definition(new_dictionary.getRoot(),wd));
					System.out.println("Definition added successfully! ");
			        traverseAndPrint(new_dictionary.getRoot());
				}
				
				else {
					System.out.println("You should choose either 0 or 1");
				}
				
				break;
				
			case 3:
				//Delete a word from the dictionary. Prompts the user to choose which dictionary to delete from.
				for (int i = 0; i<dictionaries.size();i++) {
					System.out.println((i+1) + "- Dictionary of root: " + dictionaries.get(i).root.wd.toString());
				}
				System.out.println("Pick desired dictionary: ");
				int set = scan.nextInt();
				if (set < 1 || set > dictionaries.size()) {
			            System.out.println("Invalid choice. ");
			            return;
			        }
			        BST_Dictionary dict = dictionaries.get(set - 1);
			        traverseAndPrint(dict.getRoot());
			        System.out.println("Enter desired word to delete: ");
					String key = scan.next();
					System.out.println("Enter desired description to delete: ");
					String desc = scan.next();
					dict.delete(dict.getRoot(), key, desc);
					break;
			case 4:
				//Search for a word, lets the user choose in which dictionary.
				for (int i = 0; i<dictionaries.size();i++) {
					System.out.println((i+1) + "- Dictionary of root: " + dictionaries.get(i).root.wd.toString());
				}
				System.out.println("Pick desired dictionary: ");
				int s = scan.nextInt();
				if (s < 1 || s > dictionaries.size()) {
			            System.out.println("Invalid choice. ");
			            return;
			        }
			        BST_Dictionary d = dictionaries.get(s - 1);
			        System.out.println("Enter desired word to search for: ");
					String w = scan.next();
					d.search(d.getRoot(), w, 1);
					break;
			
			case 5:
				//Exit
				System.out.println("System exitted successfully.");
				break;		
			}
		}
	}
	
	public static void main(String[] args) {
		//Main 
		menu();
	}
}
