/* Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, May 7, 2023
 * Code description: Defining what a Word_Definition is.
 * Files: BST_Dictionary.java , Node.java
 */
package Q1;
//Start of class
public class Word_Definition {
	protected String word;
	protected String description;
	//Constructor
	public Word_Definition(String w, String d) {
		word = w;
		description = d;
	}
	//Accessors
	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	//toString method
	public String toString() {
		return "Word_Definition [word = " + word + ", description = " + description + "]";
	}
	
	
	
}
