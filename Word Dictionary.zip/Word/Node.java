/* Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, May 7, 2023
 * Code description: Implementing Nodes
 * Files: BST_Dictionary.java , Word_Definition.java
 */
package Q1;

public class Node {
	protected Word_Definition wd;
	protected Node left;
	protected Node right;
	protected Node parent;
	
	public Node (Word_Definition w) {
		wd = w;
		left = null;
		right = null;
		parent = null;
	}

	public Word_Definition getWd() {
		return wd;
	}

	public void setWd(Word_Definition wd) {
		this.wd = wd;
	}

	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node right) {
		this.right = right;
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	
	

}
