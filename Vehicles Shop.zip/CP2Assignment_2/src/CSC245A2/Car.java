/*
 * Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, February 12nd, 2023
 * Code description: Implementation of class Vehicles
 * Files: Vehicles.java ,Trucks.java, Motorcycles.java, Shop.java
 */

package CSC245A2;

public class Car extends Vehicle {//First child class Car
	private int seats;
	private String model;
	private static int car_count = 0;
	
	public Car (String brand_name, String date, String color, int seats, String model) {
		super(brand_name,date,color);
		this.seats = seats;
		this.model = model;
		car_count++;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public static int getCar_count() {
		return car_count;
	}
	
	public void decrementCar_count() {
		car_count--;
	}

	 public String toString() {
	        return "Brand Name: " + getBrand_name() + ", Date of making: " + getDate() + ", Color: " + getColor() +
	                ", Number of Seats: " + seats + ", Model: " + model + " Car.";
	    }
}//Close Car
