/*
 * Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, February 12nd, 2023
 * Code description: Implementation of class Vehicles
 * Files: Car.java , Trucks.java, Motorcycles.java, Shop.java
 */

package CSC245A2;

abstract class Vehicle { //Abstract class Vehicle
	//attributes
	private String brand_name;
	private String date;
	private String color;
	
	public Vehicle (String brand_name,String date, String color) {
		this.brand_name = brand_name;
		this.date = date;
		this.color = color;
	}
	
	//Setters and Getters
	public String getBrand_name() {
		return brand_name;
	}


	public void setBrand_name(String brand_name) {
		this.brand_name = brand_name;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	abstract public String toString();
	
}//Close Vehicle class

