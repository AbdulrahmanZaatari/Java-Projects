/*
 * Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, February 12nd, 2023
 * Code description: Implementation of class Vehicles
 * Files: Vehicles.java, Car.java , Motorcycles.java, Shop.java
 */

package CSC245A2;

public class Truck extends Vehicle{//Second child class
	private int wheels;
	private static int truck_count;
	
	public Truck (String brand_name, String date, String color, int wheels) {
		super(brand_name,date,color);
		this.wheels = wheels;
		truck_count++;
	}

	public int getWheels() {
		return wheels;
	}

	public void setWheels(int wheels) {
		this.wheels = wheels;
	}

	public static int getTruck_count() {
		return truck_count;
	}
	
	public void decrementTruck_count() {
		truck_count--;
	}
	
	public String toString() {
        return "Brand Name: " + getBrand_name() + ", Date of making: " + getDate() + ", Color: " + getColor() +
                ", Number of wheels: " + wheels + " , Truck.";
    }
		
}//Close Truck class

