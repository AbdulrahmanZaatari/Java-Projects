/*
 * Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, February 12nd, 2023
 * Code description: Implementation of class Vehicles
 * Files: Vehicles.java, Car.java , Trucks.java, Shop.java
 */

package CSC245A2;

public class Motorcycle extends Vehicle {//Third child class
	private float engine_capacity;
	private static int motorcycle_count;
	
	public Motorcycle (String brand_name, String date, String color, float engine_capacity) {
		super(brand_name,date,color);
		this.engine_capacity = engine_capacity;
		motorcycle_count++;
	}

	public float getEngine_capacity() {
		return engine_capacity;
	}

	public void setEngine_capacity(float engine_capacity) {
		this.engine_capacity = engine_capacity;
		
	}
	

	public static int getMotorcycle_count() {
		return motorcycle_count;
	}
	
	public void decrementMotorcycle_count() {
		motorcycle_count--;
	}
	
	public String toString() {
        return "Brand Name: " + getBrand_name() + ", Date of making: " + getDate() + ", Color: " + getColor() +
                ", Engine capacity: " + engine_capacity + " ml , Motorcycle.";
    }

}//Close Motorcycle class

