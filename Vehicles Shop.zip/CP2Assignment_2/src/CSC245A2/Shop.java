/*
 * Name: Abdulrahman Al Zaatari
 * ID: 202201380
 * Last modified: Sunday, February 12nd, 2023
 * Code description: Implementation of class Vehicles
 * Files: Vehicles.java, Car.java , Trucks.java, Motorcycles.java
 */

package CSC245A2;
import java.util.ArrayList;
import java.util.Scanner;

public class Shop {
	static ArrayList <Vehicle> vehicles = new ArrayList<>(); //Used an array list
	public Shop(ArrayList<Vehicle> v) {
		vehicles = v;
	}
	
	public void add (Vehicle v) {
		/* Description: Adds new object of type vehicle to array list "vehicles", the type (which subclass) is inputed by the user.
		 * Parameters: 
		 * 1- v: An object of type Vehicles.
		 * Return type: void (nothing) 
		 */
		vehicles.add(v);
	}
	
	public void delete (Vehicle v) {
		/* Description: Deletes object of type vehicle from array list "vehicles", the type (which subclass) is inputed by the user where a numbered list of instances of that class is displayed. 
		 * The user then chooses the number of the object he wants to delete from the list and the count for the instances of that object is decremented by 1.
		 * Parameters: 
		 * 1- v: An object of type Vehicles.
		 * Return type: void (nothing) 
		 */
		vehicles.remove(v);
		if (v instanceof Car) {
            ((Car) v).decrementCar_count();
		}
		else if (v instanceof Truck) {
            ((Truck) v).decrementTruck_count();
        } 
		else if (v instanceof Motorcycle) {
            ((Motorcycle) v).decrementMotorcycle_count();
        }
	}
	
	public void displayType (String type) {
		/* Description: Displays all information
		 *  about objects of chosen type inputed by the user including the characteristics and count.
		 * Parameters: 
		 * 1- type: A string specifying which type to display.
		 * Return type: void (nothing) 
		 */
		int count = 0;
		System.out.println("Displaying all " + type + " vehicles:");
		for (int i = 0; i<vehicles.size(); i++) {
			if (vehicles.get(i) != null && vehicles.get(i) instanceof Vehicle) {
				if (vehicles.get(i).toString().contains(type)) {
	                System.out.println(vehicles.get(i));
	                count++;
				}
			}
		}
		if (count==0) {
			System.out.println("No vehicles of this type are found!");
		}
		
		else {
			System.out.println("Total count of " + type + " vehicles: " + count);
		}
			
	}
	
	
	public void listAll() {
		/* Description: Lists information about all Vehicles regardless of their type (Car, Trucks, Motorcycles)
		 * Return type: void (nothing) 
		 */
		for (int i = 0; i < vehicles.size(); i++) {
			if (vehicles.get(i) != null) {
				System.out.println(vehicles.get(i));
			}
		}
	}
	
	public void menu() {
		Scanner scan = new Scanner(System.in);
		int choice = 0;
		int invalid_count = 0;
		while (invalid_count<5 && choice!=5) {
			System.out.println("1.Add Vehicle\r\n"
					+ "2.Delete Vehicle\r\n"
					+ "3.Display type\r\n"
					+ "4.List all\r\n"
					+ "5.Exit\r\n"
					+ "----------------------\r\n"
					+ "Enter your choice:");
			choice = scan.nextInt();
			
			switch(choice) {
			
			case 1:
			    /* 
			    * Making the user input the required attributes and specify the type in order to create an object of specified type and invoke the add method.
			    * First we let them input the brand name, date and color which are common attributes between all vehicles.
				*/
				System.out.println("Input brand name: ");
				String b_name = scan.next();
				System.out.println("Enter date of manufacturing: ");
				String date = scan.next();
				System.out.println("Enter color: ");
				String color = scan.next();
				System.out.println("Input type of the vehicle (Car,Truck,Motorcycle): ");
				String type = scan.next();
				
				//Asking user to input type of subclass, we check if it is of type Car and then allow them to enter attributes of car: Seats and model.
				if (type.equalsIgnoreCase("Car")) {
					System.out.println("Enter number of seats: ");
					int seats = scan.nextInt();
					System.out.println("Enter model (SVU, Sedan, Hatchback): ");
					String model = scan.next();
					while (model.equalsIgnoreCase("SVU") == false && model.equalsIgnoreCase("Sedan") == false && model.equalsIgnoreCase("Hatchback") == false ) {
						System.out.println("The car's model must be one of these 3 types (SVU, Sedan, Hatchback): ");
						model = scan.next();
						}
					Car c = new Car(b_name,date,color,seats,model);
					add(c);
				}
				
				//Asking user to input type of subclass, we check if it is of type Truck and then allow them to enter attributes of truck: wheels.
				else if (type.equalsIgnoreCase("Truck")) {
					System.out.println("Enter number of wheels: ");
					int wheels = scan.nextInt();
					Truck t = new Truck(b_name,date,color,wheels);
					add(t);
				}
				
				//Asking user to input type of subclass, we check if it is of type Motorcycle and then allow him to enter attributes of motorcycle: Engine capacity.
				else if (type.equalsIgnoreCase("Motorcycle")) {
					System.out.println("Enter engine capacity: ");
					float e_capacity = scan.nextFloat();
					while (e_capacity<70 || e_capacity>120) {
					System.out.println("Engine capacity must be between 70 and 120, please input engine capacity again: ");
					e_capacity = scan.nextFloat();
					}
					Motorcycle m = new Motorcycle(b_name,date,color,e_capacity);
					add(m);
				}
				
				//If neither Car nor Truck nor Motorcycle is chosen, we print an invalid message.
				else {
					System.out.println("Invalid vehicle type!");
				}
				
				break;
				
			case 2:
				/* 
				* Making the user specify the type of Vehicle he wants to delete. 
				* A numbered list is then displayed with all instances of that type.
				* The user then chooses the number of instance they want to delete, where we then loop through the array to find that specific object and pass it as a parameter to our delete method.
				*/
				System.out.println("Input type of the vehicle (Car,Truck,Motorcycle): ");
				String delete_type = scan.next();
				if (delete_type.equalsIgnoreCase("Car")) {
					int c_count = 0;
					for (int i = 0; i<vehicles.size();i++) {
						if (vehicles.get(i) != null && vehicles.get(i) instanceof Car) {
							c_count++;
							System.out.println(c_count + "." + vehicles.get(i));
							
						}
					}
					if (c_count == 0) {
						System.out.println("No cars found!");
					}
					
					else {
						System.out.println("Choose the number of the car to delete: ");
						int c_choose = scan.nextInt();
						int c_loop_count = 0;
						for (int j = 0; j<vehicles.size();j++) {
							if (vehicles.get(j) != null && vehicles.get(j) instanceof Car) {
								c_loop_count++;
								if (c_loop_count == c_choose) {
									delete(vehicles.get(j));
								}
							}
						}
					}
						
				}
				
				else if (delete_type.equalsIgnoreCase("Truck")) {
					int t_count = 0;
					for (int i = 0; i<vehicles.size();i++) {
						if (vehicles.get(i) != null && vehicles.get(i) instanceof Truck) {
							t_count++;
							System.out.println(t_count + "." + vehicles.get(i));
						}
					}
					if (t_count == 0) {
						System.out.println("No cars found!");
					}
					
					else {
						System.out.println("Choose number of car to delete: ");
						int t_choose = scan.nextInt();
						int t_loop_count = 0;
						for (int j = 0; j<vehicles.size();j++) {
							if (vehicles.get(j) != null && vehicles.get(j) instanceof Truck) {
								t_loop_count++;
								if (t_loop_count == t_choose) {
									delete(vehicles.get(j));
								}
							}
						}
						
					}
				}
				
				
				else if (delete_type.equalsIgnoreCase("Motorcycles")) {
					int m_count = 0;
					for (int i = 0; i<vehicles.size();i++) {
						if (vehicles.get(i) != null && vehicles.get(i) instanceof Motorcycle) {
							m_count++;
							System.out.println(m_count + "." + vehicles.get(i));
						}
					}
					
					if (m_count == 0) {
						System.out.println("No cars found!");
					}
					
					else {
						System.out.println("Choose number of car to delete: ");
						int m_choose = scan.nextInt();
						int m_loop_count = 0;
						for (int j = 0; j<vehicles.size();j++) {
							if (vehicles.get(j) != null && vehicles.get(j) instanceof Motorcycle) {
								m_loop_count++;
								if (m_loop_count == m_choose) {
									delete(vehicles.get(j));
								}
							}
						}
						
					}
				}
				break;
				
			case 3:
				//Asking user to input type of subclass, then we pass it as a parameter to our display_type function.
				System.out.println("Enter type you want to display (Car,Truck,Motorcycle): ");
				String display_type = scan.next();
				displayType(display_type);
				break;
			case 4:
				//List all elements of our array list.
				listAll();
				break;
				
			case 5:
				//Output when user enters 5.
				System.out.print("System exitted successfully!");
				break;
				
			default:
				//If user enters a number not from the menu, a message telling them that their choice is invalid will be shown and invalid_count will be incremented. 
				//If user enters 5 invalid values, the program also exits.
				if(invalid_count < 4) {
				System.out.println("Invalid number, please input one of the options on the menu.");
				invalid_count++;
				}
				else if (invalid_count == 4) {
					invalid_count++;
					System.out.println("Program exitted, too many invalid inputs.");
				}
			}
		}
		
	}
	
	public static void main(String [] args) {
		ArrayList <Vehicle> vehicles = new ArrayList<>();
		Shop shop1 = new Shop (vehicles);
		shop1.menu();
	}
}//Close Shop


